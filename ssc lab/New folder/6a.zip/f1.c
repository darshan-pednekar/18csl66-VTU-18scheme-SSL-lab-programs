#include<stido.h>

int main()
{
	// this is a comment 
	printf("hello");
	/* this is another comment */
}